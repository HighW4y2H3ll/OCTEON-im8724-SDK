#
# Regular cron jobs for the oprofile package
#
0 4	* * *	root	[ -x /usr/bin/oprofile_maintenance ] && /usr/bin/oprofile_maintenance
