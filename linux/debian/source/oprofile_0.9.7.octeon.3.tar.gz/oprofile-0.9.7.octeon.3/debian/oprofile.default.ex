# Defaults for oprofile initscript
# sourced by /etc/init.d/oprofile
# installed at /etc/default/oprofile by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
