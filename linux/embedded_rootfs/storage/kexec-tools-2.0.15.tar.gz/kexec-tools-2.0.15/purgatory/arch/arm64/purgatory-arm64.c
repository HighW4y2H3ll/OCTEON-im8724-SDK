/*
 * ARM64 purgatory.
 */

#include <stdint.h>
#include <purgatory.h>

void putchar(int ch)
{
	/* Nothing for now */
}

void post_verification_setup_arch(void)
{
}

void setup_arch(void)
{
}
