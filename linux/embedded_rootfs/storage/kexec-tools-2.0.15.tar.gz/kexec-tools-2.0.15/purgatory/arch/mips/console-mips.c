#include <purgatory.h>
#include "unused.h"

void putchar(int UNUSED(ch))
{
	/* Nothing for now */
}
