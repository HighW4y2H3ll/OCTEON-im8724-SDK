#ifndef PURGATORY_PPC_H
#define PURGATORY_PPC_H

void crashdump_backup_memory(void);
void post_verification_setup_arch(void);
#endif /* PURGATORY_PPC_H */
