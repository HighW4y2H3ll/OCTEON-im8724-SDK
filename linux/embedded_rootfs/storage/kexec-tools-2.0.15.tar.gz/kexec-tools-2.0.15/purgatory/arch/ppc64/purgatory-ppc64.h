#ifndef PURGATORY_PPC64_H
#define PURGATORY_PPC64_H

void crashdump_backup_memory(void);

#endif /* PURGATORY_PPC64_H */
