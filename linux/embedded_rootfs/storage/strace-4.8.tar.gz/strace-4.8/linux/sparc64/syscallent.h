#include "../sparc/syscallent.h"
