/* tilegx32/tilepro */
#include "ioctlent.h"
