/* i386 personality */
#include "../errnoent.h"
