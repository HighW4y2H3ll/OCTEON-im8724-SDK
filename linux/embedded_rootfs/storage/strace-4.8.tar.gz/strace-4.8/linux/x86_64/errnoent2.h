/* x32 personality */
#include "../errnoent.h"
