/* i386 personality */
#include "ioctlent.h"
