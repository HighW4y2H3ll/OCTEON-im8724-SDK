/* x32 personality */
#include "../x32/syscallent.h"
