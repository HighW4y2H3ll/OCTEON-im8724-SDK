
/*---------------------------------------------------------------*/
/*---                                                         ---*/
/*--- This file (libvex_guest_mips64.h) is                     ---*/
/*--- Copyright (C) OpenWorks LLP.  All rights reserved.      ---*/
/*---                                                         ---*/
/*---------------------------------------------------------------*/

/*
   This file is part of LibVEX, a library for dynamic binary
   instrumentation and translation.

   Copyright (C) 2004-2009 OpenWorks LLP.  All rights reserved.

   This library is made available under a dual licensing scheme.

   If you link LibVEX against other code all of which is itself
   licensed under the GNU General Public License, version 2 dated June
   1991 ("GPL v2"), then you may use LibVEX under the terms of the GPL
   v2, as appearing in the file LICENSE.GPL.  If the file LICENSE.GPL
   is missing, you can obtain a copy of the GPL v2 from the Free
   Software Foundation Inc., 51 Franklin St, Fifth Floor, Boston, MA
   02110-1301, USA.

   For any other uses of LibVEX, you must first obtain a commercial
   license from OpenWorks LLP.  Please contact info@open-works.co.uk
   for information about commercial licensing.

   This software is provided by OpenWorks LLP "as is" and any express
   or implied warranties, including, but not limited to, the implied
   warranties of merchantability and fitness for a particular purpose
   are disclaimed.  In no event shall OpenWorks LLP be liable for any
   direct, indirect, incidental, special, exemplary, or consequential
   damages (including, but not limited to, procurement of substitute
   goods or services; loss of use, data, or profits; or business
   interruption) however caused and on any theory of liability,
   whether in contract, strict liability, or tort (including
   negligence or otherwise) arising in any way out of the use of this
   software, even if advised of the possibility of such damage.

   Neither the names of the U.S. Department of Energy nor the
   University of California nor the names of its contributors may be
   used to endorse or promote products derived from this software
   without prior written permission.


   This file has been modified for MIPS support by SEECS NUST and
   Cavium Networks. Contact Dr. Zahid Anwar: zahid.anwar@seecs.edu.pk

*/

#ifndef __LIBVEX_PUB_GUEST_MIPS64_H
#define __LIBVEX_PUB_GUEST_MIPS64_H

#include "libvex_basictypes.h"
#include "libvex_emwarn.h"


//added by Sumayya
#define VEX_GUEST_MIPS64_REDIR_STACK_SIZE (32/*entries*/ * 2/*words per entry*/)
//end by Sumayya


/*---------------------------------------------------------------*/
/*--- Vex's representation of the MIPS64 CPU state             ---*/
/*---------------------------------------------------------------*/


typedef
   struct {
      /* General Purpose Registers */
      /*   0 */ ULong guest_GPR0;
      /*   8 */ ULong guest_GPR1;
      /*  16 */ ULong guest_GPR2;
      /*  24 */ ULong guest_GPR3;
      /*  32 */ ULong guest_GPR4;
      /*  40 */ ULong guest_GPR5;
      /*  48 */ ULong guest_GPR6;
      /*  56 */ ULong guest_GPR7;
      /*  64 */ ULong guest_GPR8;
      /*  72 */ ULong guest_GPR9;
      /*  80 */ ULong guest_GPR10;
      /*  88 */ ULong guest_GPR11;
      /*  96 */ ULong guest_GPR12;
      /* 104 */ ULong guest_GPR13;
      /* 112 */ ULong guest_GPR14;
      /* 120 */ ULong guest_GPR15;
      /* 128 */ ULong guest_GPR16;
      /* 136 */ ULong guest_GPR17;
      /* 144 */ ULong guest_GPR18;
      /* 152 */ ULong guest_GPR19;
      /* 160 */ ULong guest_GPR20;
      /* 168 */ ULong guest_GPR21;
      /* 176 */ ULong guest_GPR22;
      /* 184 */ ULong guest_GPR23;
      /* 192 */ ULong guest_GPR24;
      /* 200 */ ULong guest_GPR25;
      /* 208 */ ULong guest_GPR26;
      /* 216 */ ULong guest_GPR27;
      /* 224 */ ULong guest_GPR28;
      /* 232 */ ULong guest_GPR29;
      /* 240 */ ULong guest_GPR30;
      /* 248 */ ULong guest_GPR31;

      /* 256 */ ULong guest_PC;    // IP (no arch visible register)
      /* 264 */ ULong guest_HI;
      /* 272 */ ULong guest_LO;
      /* CAUTION: Do not change the order of the above registers,
                  as these are used in multiplication operations.
                  see comments in host_mips64_defs.c file. */

      /* 280 */ ULong guest_PC_AT_SYSCALL;
      /* 288 */ ULong guest_MPL0;
      /* 296 */ ULong guest_MPL1;
      /* 304 */ ULong guest_MPL2;
      /* 312 */ ULong guest_P0;
      /* 320 */ ULong guest_P1;
      /* 328 */ ULong guest_P2;

      /* Emulation warnings */
      /* 336 */ UInt guest_EMWARN;
      /* 340 */ UInt padding;
      /* Used to record the unredirected guest address at the start of
         a translation whose start has been redirected.  By reading
         this pseudo-register shortly afterwards, the translation can
         find out what the corresponding no-redirection address was.
         Note, this is only set for wrap-style redirects, not for
         replace-style ones. */
      /* 344 */ ULong guest_NRADDR;
      /* 352 */ ULong guest_NRADDR_GPR2;
      /* 360 */ ULong guest_TISTART;
      /* 368 */ ULong guest_TILEN;

      /* 376 */ ULong guest_HWREG_29;   /* Holds the TLS address in user space */
      /* 384 */ ULong guest_REDIR_STACK[VEX_GUEST_MIPS64_REDIR_STACK_SIZE];
      /* 448 */
   }
   VexGuestMIPS64State;


/*---------------------------------------------------------------*/
/*--- Utility functions for MIPS64 guest stuff.                ---*/
/*---------------------------------------------------------------*/

/* ALL THE FOLLOWING ARE VISIBLE TO LIBRARY CLIENT */

/* Initialise all guest MIPS64 state. */
extern
void LibVEX_GuestMIPS64_initialise ( /*OUT*/VexGuestMIPS64State* vex_state );

//extern VexGuestMIPS64State MIPS64Guest_layout;
#endif /* ndef __LIBVEX_PUB_GUEST_MIPS64_H */


/*---------------------------------------------------------------*/
/*---                                    libvex_guest_mips64.h ---*/
/*---------------------------------------------------------------*/
